import './App.css';
import InputForm from './components/handlingInputs/input_form';
// import Register from './components/regForm/reg';
// import Carousal from './components/carousal/main';
// import TempController from './components/tempControl/main';
// import Webpage from './components/webpage/main';

function App() {
  return (
    <>
      <InputForm/>
    </>
  );
}

export default App;
