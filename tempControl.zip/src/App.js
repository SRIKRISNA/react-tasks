import './App.css';
// import Carousal from './components/carousal/main';
import TempController from './components/tempControl/main';
// import Webpage from './components/webpage/main';

function App() {
  return (
    <>
      <TempController/>
    </>
  );
}

export default App;
