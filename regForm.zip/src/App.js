import './App.css';
import Register from './components/regForm/reg';
// import Carousal from './components/carousal/main';
// import TempController from './components/tempControl/main';
// import Webpage from './components/webpage/main';

function App() {
  return (
    <>
      <Register/>
    </>
  );
}

export default App;
