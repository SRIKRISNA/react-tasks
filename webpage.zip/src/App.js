import './App.css';
import Webpage from './components/webpage/main';

function App() {
  return (
    <>
      <Webpage/>
    </>
  );
}

export default App;
