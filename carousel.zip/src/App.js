import './App.css';
import Carousal from './components/carousal/main';
// import Webpage from './components/webpage/main';

function App() {
  return (
    <>
      <Carousal/>
    </>
  );
}

export default App;
